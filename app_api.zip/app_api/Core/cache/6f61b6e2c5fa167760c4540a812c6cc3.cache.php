<?php if(!defined('INCLUDE_PATH')){die('error!this is a cache file!');};?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>筑梦提示您</title>
<link href="/style/css/layout.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="/style/js/jquery.js"></script>
</head>
<body>